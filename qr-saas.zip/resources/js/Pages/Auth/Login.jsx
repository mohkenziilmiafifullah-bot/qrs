import { Head, Link, useForm, usePage } from '@inertiajs/react';

function GoogleMark() {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.8 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.5a4.7 4.7 0 0 1-2 3.1v2.5h3.2c1.9-1.8 3.1-4.4 3.1-7.4Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.7-2.4l-3.2-2.5c-.9.6-2 .9-3.5.9-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.9a6 6 0 0 1 0-3.8V7.5H3.1a10 10 0 0 0 0 9l3.3-2.6Z"/><path fill="#EA4335" d="M12 6c1.6 0 3 .6 4.1 1.6l3-3A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.8 9.4 6 12 6Z"/></svg>;
}

export default function Login() {
    const { errors } = usePage().props;
    const { data, setData, post, processing } = useForm({ email: '', password: '' });

    return <div className="login-page min-h-screen flex items-center justify-center px-6"><Head title="Masuk" /><main className="login-card w-full max-w-sm"><img src="/images/qr-review-logo.png" alt="QR Review" className="login-logo" /><p className="login-brand">QR REVIEW</p><h1>Masuk ke akun Anda</h1><p className="login-copy">Masuk dengan Google atau email dan password Anda.</p>{(errors.google || errors.email) && <p className="login-error">{errors.google || errors.email}</p>}<a href="/auth/google" className="google-login-button"><GoogleMark /><span>Masuk dengan Google</span></a><div className="login-divider"><span>atau</span></div><form onSubmit={(event) => { event.preventDefault(); post('/login'); }} className="login-form"><label>Email<input type="email" value={data.email} onChange={(event) => setData('email', event.target.value)} autoComplete="email" required /></label><label>Password<input type="password" value={data.password} onChange={(event) => setData('password', event.target.value)} autoComplete="current-password" required /></label><button type="submit" disabled={processing} className="login-submit">{processing ? 'Memproses…' : 'Masuk'}</button></form><p className="login-register">Belum punya akun? <Link href="/register">Daftar sekarang</Link></p></main></div>;
}
